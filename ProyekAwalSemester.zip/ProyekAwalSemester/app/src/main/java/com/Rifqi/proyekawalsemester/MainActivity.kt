package com.Rifqi.proyekawalsemester

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.Rifqi.proyekawalsemester.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.buttonLogin.setOnClickListener { cekPassword() }
    }

    private fun cekPassword() {
        val namaMahasiswa = binding.editNamamhs.text.toString()
        val nimMahasiswa = binding.editNim.text.toString()
        if (namaMahasiswa.isEmpty() || nimMahasiswa.isEmpty()) {
            Toast.makeText(this, "Masukkan Nama dan NIM terlebih dahulu !", Toast.LENGTH_SHORT)
                .show()
            return

        }
        if (namaMahasiswa == "Rifqi Yusdianto" && nimMahasiswa == "203110015") {
            val intent = Intent(this, User::class.java)
            intent.putExtra("nama_mahasiswa", binding.editNamamhs.text.toString())
            startActivity(intent)
        } else {
            Toast.makeText(this, "Nama Mahasiswa atau NIM salah", Toast.LENGTH_SHORT).show()
            return
        }
    }
}




