package com.Rifqi.proyekawalsemester

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.Rifqi.proyekawalsemester.databinding.ActivityUserBinding

class User : AppCompatActivity() {
    companion object {

        const val WEB_SATU = "https://github.com/yusdianto1"
        const val WEB_DUA = "https://elearning.utdi.ac.id/user/profile.php?id=829"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val binding = ActivityUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.buttonGithub.setOnClickListener { Github() }
        binding.buttonEla.setOnClickListener { Ela() }
    }
    private fun Github() {
        val queryUrl: Uri = Uri.parse(WEB_SATU)

        val intent = Intent(Intent.ACTION_VIEW, queryUrl)
        startActivity(intent)
    }
    private fun Ela() {
        val duaUrl: Uri = Uri.parse(WEB_DUA)

        val intentdua = Intent(Intent.ACTION_VIEW, duaUrl)
        startActivity(intentdua)
    }
}
